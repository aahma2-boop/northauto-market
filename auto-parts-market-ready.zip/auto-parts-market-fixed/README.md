# Auto Parts Market

A North America-wide auto parts marketplace: sellers in Canada and the USA list parts in CAD or USD, buyers browse everything converted to USD with duty estimates and seller locations.

## Features
- Stripe Connect payments
- Duty/tax estimator (USMCA + MFN + GST/HST)
- Listings with photos
- Auth (register/login)
- Messaging
- Saved items
- SQLite database with seed data
- Fully static frontend served by Express

## Quick start

```bash
npm install
npm start
```

Visit: http://localhost:3000

## Deploying on Render

- Add persistent disk at `/data`
- Add environment variables:
  - `DATA_DIR=/data`
  - `FX_CAD_USD=0.73`
  - `PLATFORM_FEE_PCT=10`
  - `APP_URL=https://yourdomain.onrender.com`
  - `STRIPE_SECRET_KEY=`
  - `STRIPE_WEBHOOK_SECRET=`

## Customer Purchase Flow

The marketplace now uses a public checkout flow:

1. Customer clicks an auto part.
2. Product detail page displays the customer price.
3. Customer clicks **Buy Now — Secure Checkout**.
4. The server loads the listing from SQLite and calculates `supplier cost × 1.15`.
5. Stripe Checkout collects payment, billing address, shipping address and phone.
6. The Stripe webhook marks the order as completed and the listing as sold.

The supplier cost is never trusted from the browser; the server calculates the customer price.

### Example

If the supplier/listing cost is **$100 USD**, the customer is charged **$115 USD**. The gross markup is **$15** before Stripe fees, shipping, taxes, refunds, and other business expenses.

### Stripe setup

Copy `.env.example` to `.env` and set:

- `STRIPE_SECRET_KEY`
- `STRIPE_WEBHOOK_SECRET`
- `APP_URL`
- `MARKUP_PCT=15`

For production, configure a Stripe webhook endpoint at:

`https://YOUR-DOMAIN/api/payments/webhook`

Listen for `checkout.session.completed` and `checkout.session.expired`.

Do not put your Stripe secret key in GitHub.
