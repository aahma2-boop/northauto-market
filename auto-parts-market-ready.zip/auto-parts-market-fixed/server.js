const express = require('express');
const cookieParser = require('cookie-parser');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const db = require('./db');
const duty = require('./duty');
const payments = require('./payments');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || __dirname;
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');

fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// Static frontend and product images
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(UPLOAD_DIR));
app.use(cookieParser());

// Stripe webhook MUST receive the raw body before express.json()
app.post('/api/payments/webhook', express.raw({ type: 'application/json' }), (req, res) => {
  try {
    const out = payments.handleWebhook(req);
    if (out && out.status) return res.status(out.status).json({ error: out.error });
    res.json(out);
  } catch (e) {
    console.error('Webhook error:', e);
    res.status(500).json({ error: e.message });
  }
});

app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));

const upload = multer({
  dest: UPLOAD_DIR,
  limits: { fileSize: 5 * 1024 * 1024 }
});

app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Public product/listing API
app.get('/api/listings', (req, res) => {
  const rows = db.prepare('SELECT * FROM listings ORDER BY created_at DESC').all();
  res.json(rows);
});

app.get('/api/listings/:id', (req, res) => {
  const listing = db.prepare('SELECT * FROM listings WHERE id=?').get(req.params.id);
  if (!listing) return res.status(404).json({ error: 'Listing not found' });
  res.json(listing);
});

// Product page uses the same frontend app with the listing id in the URL.
app.get('/product/:id', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'product.html'));
});

app.get('/success', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'success.html'));
});

app.get('/cancel', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'cancel.html'));
});

// AUTO-POPULATE DEMO LISTINGS
async function seedListingsFromExternal() {
  const existingCount = db.prepare('SELECT COUNT(*) as c FROM listings').get().c;
  if (existingCount > 2) return;

  console.log('🔄 Loading marketplace listings...');

  const externalListings = [
    { title: 'Winter Tires - Bridgestone Turanza', category: 'Tires', price: 520, currency: 'CAD', condition: 'New', fitment: '215/60R16', country: 'Canada', city: 'Vancouver', region: 'BC', description: 'Premium winter tires, excellent tread depth' },
    { title: 'All-Season Tires - Goodyear', category: 'Tires', price: 380, currency: 'USD', condition: 'Used', fitment: '205/55R16', country: 'USA', city: 'Seattle', region: 'WA', description: 'Good condition, 60% tread remaining' },
    { title: 'Summer Performance Tires - Michelin Pilot', category: 'Tires', price: 650, currency: 'CAD', condition: 'New', fitment: '225/45R17', country: 'Canada', city: 'Toronto', region: 'ON', description: 'Sports performance, DOT 2023' },
    { title: 'Truck Tires - BFGoodrich', category: 'Tires', price: 450, currency: 'USD', condition: 'New', fitment: 'LT265/75R16', country: 'USA', city: 'Dallas', region: 'TX', description: 'Off-road capable, excellent grip' },
    { title: 'Brake Pads - OEM Toyota', category: 'Brakes', price: 85, currency: 'USD', condition: 'New', fitment: 'Toyota Camry 2015-2023', country: 'USA', city: 'Chicago', region: 'IL', description: 'OEM replacement, low dust formula' },
    { title: 'Brake Rotors - Drilled & Slotted', category: 'Brakes', price: 220, currency: 'CAD', condition: 'New', fitment: 'Honda Civic', country: 'Canada', city: 'Calgary', region: 'AB', description: 'Performance upgrade, improved cooling' },
    { title: 'Air Filter - K&N Reusable', category: 'Engine', price: 65, currency: 'CAD', condition: 'New', fitment: 'Ford F-150 2009-2020', country: 'Canada', city: 'Edmonton', region: 'AB', description: 'Washable & reusable, lifetime warranty' },
    { title: 'Spark Plugs Set - NGK', category: 'Engine', price: 45, currency: 'USD', condition: 'New', fitment: 'V8 engines', country: 'USA', city: 'Houston', region: 'TX', description: 'OEM quality, precision engineered' },
    { title: 'Oil Filter - Mobil 1', category: 'Engine', price: 15, currency: 'USD', condition: 'New', fitment: 'Universal', country: 'USA', city: 'Phoenix', region: 'AZ', description: 'Premium protection, extended service' },
    { title: 'Shock Absorbers - Monroe', category: 'Suspension', price: 180, currency: 'USD', condition: 'New', fitment: 'Honda Accord', country: 'USA', city: 'Los Angeles', region: 'CA', description: 'Factory-matched performance' },
    { title: 'Coil Springs - OEM', category: 'Suspension', price: 120, currency: 'CAD', condition: 'New', fitment: 'Chevy Silverado', country: 'Canada', city: 'Winnipeg', region: 'MB', description: 'Heavy-duty springs' },
    { title: 'Tie Rods - Moog', category: 'Suspension', price: 95, currency: 'USD', condition: 'New', fitment: 'Ford Focus', country: 'USA', city: 'Boston', region: 'MA', description: 'Improves steering response' },
    { title: 'Clutch Kit - LUK', category: 'Transmission', price: 350, currency: 'USD', condition: 'New', fitment: 'Volkswagen GTI', country: 'USA', city: 'Detroit', region: 'MI', description: 'Performance upgrade' },
    { title: 'Manual Transmission Fluid', category: 'Transmission', price: 28, currency: 'CAD', condition: 'New', fitment: 'Subaru', country: 'Canada', city: 'Ottawa', region: 'ON', description: 'Synthetic, 1L bottle' },
    { title: 'Car Battery - Optima', category: 'Electrical', price: 280, currency: 'USD', condition: 'New', fitment: 'Universal', country: 'USA', city: 'New York', region: 'NY', description: 'AGM technology, 4-year warranty' },
    { title: 'Alternator - Bosch', category: 'Electrical', price: 250, currency: 'CAD', condition: 'New', fitment: 'Mazda CX-5', country: 'Canada', city: 'Quebec City', region: 'QC', description: 'OEM quality, 130A output' },
    { title: 'Starter Motor - Denso', category: 'Electrical', price: 180, currency: 'USD', condition: 'Rebuilt', fitment: 'Toyota Corolla', country: 'USA', city: 'San Francisco', region: 'CA', description: 'Core charge included' },
    { title: 'Door Handle Set - Chrome', category: 'Body', price: 65, currency: 'CAD', condition: 'New', fitment: 'Jeep Wrangler', country: 'Canada', city: 'Vancouver', region: 'BC', description: 'Complete set with hardware' },
    { title: 'Bumper Cover - OEM', category: 'Body', price: 150, currency: 'USD', condition: 'New', fitment: 'BMW 5 Series', country: 'USA', city: 'Washington DC', region: 'DC', description: 'Perfect condition' },
    { title: 'Side Mirror - Power', category: 'Body', price: 120, currency: 'CAD', condition: 'Used', fitment: 'Ford Mustang', country: 'Canada', city: 'Toronto', region: 'ON', description: 'Heated, works perfectly' },
    { title: 'Seat Covers - Leather', category: 'Interior', price: 280, currency: 'USD', condition: 'New', fitment: 'Universal', country: 'USA', city: 'Austin', region: 'TX', description: 'Premium leather, all colors' },
    { title: 'Floor Mats - OEM', category: 'Interior', price: 75, currency: 'CAD', condition: 'New', fitment: 'Honda Civic', country: 'Canada', city: 'Calgary', region: 'AB', description: 'Factory original, 4-piece set' },
    { title: 'Radiator - OEM', category: 'Cooling', price: 320, currency: 'CAD', condition: 'New', fitment: 'Hyundai Elantra', country: 'Canada', city: 'Montreal', region: 'QC', description: 'Full aluminum, high-efficiency' },
    { title: 'Water Pump - Aisin', category: 'Cooling', price: 185, currency: 'USD', condition: 'New', fitment: 'Toyota Highlander', country: 'USA', city: 'Tampa', region: 'FL', description: 'Japanese OEM quality' },
    { title: 'Thermostat - Motorcraft', category: 'Cooling', price: 55, currency: 'CAD', condition: 'New', fitment: 'Ford Focus', country: 'Canada', city: 'Winnipeg', region: 'MB', description: 'OEM replacement' },
    { title: 'Fuel Filter - Mahle', category: 'Fuel', price: 40, currency: 'USD', condition: 'New', fitment: 'Volkswagen Jetta', country: 'USA', city: 'Portland', region: 'OR', description: 'Premium filtration' },
    { title: 'Fuel Pump - Walbro', category: 'Fuel', price: 220, currency: 'CAD', condition: 'New', fitment: 'Mustang GT', country: 'Canada', city: 'Vancouver', region: 'BC', description: 'High-flow performance pump' },
    { title: 'Fuel Injectors - Bosch', category: 'Fuel', price: 145, currency: 'USD', condition: 'New', fitment: 'BMW X3', country: 'USA', city: 'Seattle', region: 'WA', description: 'Set of 6, tested & balanced' },
    { title: 'Muffler - Borla', category: 'Exhaust', price: 450, currency: 'CAD', condition: 'New', fitment: 'Dodge Charger', country: 'Canada', city: 'Toronto', region: 'ON', description: 'Performance exhaust, aggressive sound' },
    { title: 'Catalytic Converter - OEM', category: 'Exhaust', price: 520, currency: 'USD', condition: 'New', fitment: 'Honda CR-V', country: 'USA', city: 'Portland', region: 'OR', description: 'EPA certified' },
    { title: 'Exhaust Pipe - Stainless', category: 'Exhaust', price: 180, currency: 'CAD', condition: 'New', fitment: 'Universal', country: 'Canada', city: 'Calgary', region: 'AB', description: 'Mandrel bent, 3 inch' }
  ];

  const bcrypt = require('bcryptjs');
  const now = Date.now();
  let sellerId = 1;

  try {
    const seller = db.prepare(`
      INSERT INTO users (name,email,pass_hash,country,city,region,created_at)
      VALUES (?,?,?,?,?,?,?)
    `).run(
      'Auto Parts Distributor',
      'distributor@parts.local',
      bcrypt.hashSync('distributor123', 10),
      'Canada',
      'Toronto',
      'ON',
      now
    );
    sellerId = seller.lastInsertRowid;
  } catch (e) {
    const existing = db.prepare('SELECT id FROM users ORDER BY id LIMIT 1').get();
    if (existing) sellerId = existing.id;
  }

  for (const listing of externalListings) {
    const exists = db.prepare('SELECT id FROM listings WHERE title=? AND price=? AND currency=?')
      .get(listing.title, listing.price, listing.currency);
    if (exists) continue;

    db.prepare(`
      INSERT INTO listings
      (user_id,title,category,condition,price,currency,fitment,description,
       country,city,region,made_in,sold,created_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    `).run(
      sellerId, listing.title, listing.category, listing.condition,
      listing.price, listing.currency, listing.fitment || 'Universal',
      listing.description, listing.country, listing.city, listing.region,
      'Various', 0, now - Math.floor(Math.random() * 30 * 24 * 60 * 60 * 1000)
    );
  }

  console.log('✅ Marketplace listings loaded');
}

seedListingsFromExternal().catch(console.error);

// AUTH
app.post('/api/auth/register', (req, res) => {
  const { name, email, password, country, city, region } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: 'Missing fields' });

  const bcrypt = require('bcryptjs');
  const hash = bcrypt.hashSync(password, 10);

  try {
    const result = db.prepare(`
      INSERT INTO users (name,email,pass_hash,country,city,region,created_at)
      VALUES (?,?,?,?,?,?,?)
    `).run(name, email, hash, country || 'USA', city || '', region || '', Date.now());
    res.json({ ok: true, id: result.lastInsertRowid });
  } catch {
    res.status(400).json({ error: 'Email already exists' });
  }
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const bcrypt = require('bcryptjs');
  const user = db.prepare('SELECT * FROM users WHERE email=?').get(email);

  if (!user || !bcrypt.compareSync(password, user.pass_hash)) {
    return res.status(400).json({ error: 'Invalid credentials' });
  }

  const token = require('crypto').randomBytes(32).toString('hex');
  db.prepare('INSERT INTO sessions (token,user_id,created_at) VALUES (?,?,?)')
    .run(token, user.id, Date.now());

  res.cookie('session', token, { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production' });
  res.json({ ok: true });
});

app.post('/api/auth/logout', (req, res) => {
  const token = req.cookies.session;
  if (token) db.prepare('DELETE FROM sessions WHERE token=?').run(token);
  res.clearCookie('session');
  res.json({ ok: true });
});

// Seller listing creation remains protected
app.post('/api/listings', upload.single('image'), (req, res) => {
  const token = req.cookies.session;
  const session = db.prepare('SELECT * FROM sessions WHERE token=?').get(token);
  if (!session) return res.status(401).json({ error: 'Not logged in' });

  const {
    title, category, condition, price, currency,
    fitment, description, country, city, region, made_in
  } = req.body;

  if (!title || !price) return res.status(400).json({ error: 'Title and price are required' });

  const image = req.file ? req.file.filename : '';

  const result = db.prepare(`
    INSERT INTO listings
    (user_id,title,category,condition,price,currency,fitment,description,
     country,city,region,made_in,image,sold,created_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
  `).run(
    session.user_id, title, category, condition, Number(price), currency || 'USD',
    fitment, description, country, city, region, made_in, image, 0, Date.now()
  );

  res.json({ ok: true, id: result.lastInsertRowid });
});

// Duty estimator
app.post('/api/duty', (req, res) => {
  res.json(duty.estimate(req.body));
});

// PUBLIC CHECKOUT — customers do NOT need an account.
// The server fetches the listing and calculates the 15% markup.
app.post('/api/payments/checkout', async (req, res) => {
  try {
    const listingId = Number(req.body.listing_id);
    if (!Number.isInteger(listingId) || listingId <= 0) {
      return res.status(400).json({ error: 'Invalid listing ID' });
    }

    const listing = db.prepare('SELECT * FROM listings WHERE id=?').get(listingId);
    if (!listing) return res.status(404).json({ error: 'Listing not found' });
    if (listing.sold) return res.status(409).json({ error: 'This item has already been sold' });

    const result = await payments.checkout(listing);
    res.json(result);
  } catch (e) {
    console.error('Checkout error:', e);
    res.status(500).json({ error: e.message || 'Unable to start checkout' });
  }
});

app.listen(PORT, () => {
  console.log(`✅ Auto Parts Market running → http://localhost:${PORT}`);
});
