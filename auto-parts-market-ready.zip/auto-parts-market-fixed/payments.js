const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY || 'sk_test_dummy');
const db = require('./db');

const MARKUP_PCT = Number(process.env.MARKUP_PCT || 15);
const APP_URL = process.env.APP_URL || 'http://localhost:3000';

function sellingPrice(cost) {
  return Math.round(Number(cost) * (1 + MARKUP_PCT / 100) * 100) / 100;
}

async function checkout(listing) {
  if (!listing) throw new Error('Listing not found');
  if (listing.sold) throw new Error('This item has already been sold');

  const customerPrice = sellingPrice(listing.price);
  const currency = (listing.currency || 'USD').toLowerCase();

  // Stripe requires a fully-qualified image URL. Only add one when APP_URL is configured.
  const images = listing.image && /^https?:\/\//i.test(APP_URL)
    ? [`${APP_URL}/uploads/${listing.image}`]
    : [];

  const session = await stripe.checkout.sessions.create({
    mode: 'payment',
    line_items: [{
      price_data: {
        currency,
        product_data: {
          name: listing.title,
          description: `Fitment: ${listing.fitment || 'Universal'}`
        },
        unit_amount: Math.round(customerPrice * 100)
      },
      quantity: 1
    }],
    billing_address_collection: 'required',
    shipping_address_collection: {
      allowed_countries: ['CA', 'US']
    },
    phone_number_collection: { enabled: true },
    success_url: `${APP_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${APP_URL}/cancel?item=${encodeURIComponent(listing.title)}`,
    metadata: {
      listing_id: String(listing.id),
      supplier_cost: String(Number(listing.price).toFixed(2)),
      customer_price: String(customerPrice.toFixed(2)),
      markup_percent: String(MARKUP_PCT)
    }
  });

  db.prepare(`
    INSERT INTO orders
    (buyer_id,seller_id,listing_id,amount,currency,status,stripe_session_id,created_at)
    VALUES (?,?,?,?,?,?,?,?)
  `).run(
    0,
    listing.user_id,
    listing.id,
    customerPrice,
    listing.currency || 'USD',
    'pending',
    session.id,
    Date.now()
  );

  return {
    sessionId: session.id,
    url: session.url,
    supplierCost: Number(listing.price),
    customerPrice,
    markup: Math.round((customerPrice - Number(listing.price)) * 100) / 100,
    markupPercent: MARKUP_PCT
  };
}

function handleWebhook(req) {
  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!webhookSecret) {
    return { error: 'STRIPE_WEBHOOK_SECRET is not configured', status: 500 };
  }

  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
  } catch (e) {
    return { error: `Webhook signature verification failed: ${e.message}`, status: 400 };
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const order = db.prepare('SELECT * FROM orders WHERE stripe_session_id=?').get(session.id);

    if (order) {
      db.prepare('UPDATE orders SET status=? WHERE id=?').run('completed', order.id);
      db.prepare('UPDATE listings SET sold=1 WHERE id=? AND sold=0').run(order.listing_id);
    }
  }

  if (event.type === 'checkout.session.expired') {
    const session = event.data.object;
    db.prepare('UPDATE orders SET status=? WHERE stripe_session_id=? AND status=?')
      .run('expired', session.id, 'pending');
  }

  return { received: true };
}

module.exports = { checkout, handleWebhook, sellingPrice };
