const api = {
  async listings() {
    const res = await fetch('/api/listings');
    if (!res.ok) throw new Error('Failed to load listings');
    return res.json();
  }
};

const state = { listings: [], filtered: [], categories: new Map() };

function toast(msg) {
  const el = document.getElementById('toast');
  if (!el) return;
  el.textContent = msg;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 2500);
}

function money(price, currency) {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency || 'USD'
  }).format(Number(price));
}

function sellingPrice(cost) {
  return Math.round(Number(cost) * 1.15 * 100) / 100;
}

function buildCategories() {
  state.categories.clear();
  for (const l of state.listings) {
    state.categories.set(l.category, (state.categories.get(l.category) || 0) + 1);
  }
}

function renderCategories() {
  const ul = document.getElementById('categoryList');
  if (!ul) return;
  ul.innerHTML = '';

  const all = document.createElement('li');
  all.className = 'category-item active';
  all.innerHTML = `<span>All Parts</span><span class="category-count">${state.listings.length}</span>`;
  all.onclick = () => {
    state.filtered = [];
    renderListings();
  };
  ul.appendChild(all);

  for (const [cat, count] of state.categories.entries()) {
    const li = document.createElement('li');
    li.className = 'category-item';
    li.innerHTML = `<span>${cat}</span><span class="category-count">${count}</span>`;
    li.onclick = () => {
      state.filtered = state.listings.filter(l => l.category === cat);
      renderListings();
    };
    ul.appendChild(li);
  }
}

function renderListings() {
  const grid = document.getElementById('productGrid');
  const list = state.filtered.length ? state.filtered : state.listings;

  document.getElementById('resultsCount').textContent =
    list.length ? `${list.length} listings` : 'No listings found';

  if (!list.length) {
    grid.innerHTML = `<div class="empty-state">No parts found. Try a different search.</div>`;
    return;
  }

  grid.innerHTML = '';

  for (const l of list) {
    const card = document.createElement('article');
    card.className = 'product-card' + (l.sold ? ' sold' : '');
    const price = sellingPrice(l.price);

    card.innerHTML = `
      <div class="product-image">
        <span>${escapeHtml(l.category || 'Auto Part')}</span>
        ${l.image ? `<img src="/uploads/${encodeURIComponent(l.image)}" alt="${escapeHtml(l.title)}">` : `<div class="no-image">🔧</div>`}
        ${l.sold ? `<div class="sold-stamp">SOLD</div>` : ''}
      </div>
      <div class="product-info">
        <div class="product-name">${escapeHtml(l.title)}</div>
        <div class="product-meta">${escapeHtml(l.fitment || 'Universal fit')}</div>
        <div class="seller-row">${escapeHtml(l.city || '')}, ${escapeHtml(l.region || '')} · ${escapeHtml(l.country || '')}</div>
        <div class="product-footer">
          <div>
            <div class="product-price">${money(price, l.currency)}</div>
            <div class="price-note">Includes 15% marketplace markup</div>
          </div>
          <button class="buy-btn" ${l.sold ? 'disabled' : ''}>${l.sold ? 'Sold' : 'Buy Now'}</button>
        </div>
      </div>
    `;

    card.addEventListener('click', (e) => {
      if (e.target.closest('.buy-btn')) return;
      window.location.href = `/product/${l.id}`;
    });

    const buy = card.querySelector('.buy-btn');
    if (buy && !l.sold) {
      buy.addEventListener('click', async () => {
        window.location.href = `/product/${l.id}`;
      });
    }

    grid.appendChild(card);
  }
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
  }[c]));
}

function setupSearchSort() {
  const input = document.getElementById('searchInput');
  const sort = document.getElementById('sortSelect');

  function apply() {
    const q = input.value.trim().toLowerCase();
    let list = state.listings.filter(l => {
      const text = `${l.title} ${l.category} ${l.fitment} ${l.description} ${l.country}`.toLowerCase();
      return !q || text.includes(q);
    });

    if (sort.value === 'price_low') list.sort((a, b) => sellingPrice(a.price) - sellingPrice(b.price));
    if (sort.value === 'price_high') list.sort((a, b) => sellingPrice(b.price) - sellingPrice(a.price));
    if (sort.value === 'newest') list.sort((a, b) => b.created_at - a.created_at);

    state.filtered = list;
    renderListings();
  }

  input?.addEventListener('input', apply);
  sort?.addEventListener('change', apply);
}

async function init() {
  try {
    const listings = await api.listings();
    state.listings = listings;
    state.filtered = [];
    buildCategories();
    renderCategories();
    renderListings();
    setupSearchSort();

    document.getElementById('statListings').textContent = listings.length;
    document.getElementById('statSellers').textContent = new Set(listings.map(l => l.user_id)).size;
  } catch (e) {
    console.error(e);
    toast('Failed to load listings');
  }
}

document.addEventListener('DOMContentLoaded', init);
